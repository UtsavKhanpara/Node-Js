// seed/questions.js
import Question from '../models/Question.js';

const data = [
  {
    text: 'Which is the largest animal in the world?',
    options: ['Shark', 'Blue whale', 'Elephant', 'Giraffe'],
    correctIndex: 1
  },
  {
    text: 'What is the capital of France?',
    options: ['Berlin', 'Madrid', 'Paris', 'Lisbon'],
    correctIndex: 2
  },
  {
    text: 'Which planet is known as the Red Planet?',
    options: ['Mars', 'Venus', 'Jupiter', 'Saturn'],
    correctIndex: 0
  },
  {
    text: 'What is 2 + 2 × 2?',
    options: ['6', '8', '4', '10'],
    correctIndex: 0
  },
  {
    text: 'Who wrote “Hamlet”?',
    options: ['Charles Dickens', 'William Shakespeare', 'Mark Twain', 'Jane Austen'],
    correctIndex: 1
  },
  {
    text: 'Which gas do plants absorb from the atmosphere?',
    options: ['Oxygen', 'Carbon dioxide', 'Nitrogen', 'Hydrogen'],
    correctIndex: 1
  },
  {
    text: 'What is the boiling point of water at sea level?',
    options: ['90°C', '100°C', '110°C', '120°C'],
    correctIndex: 1
  },
  {
    text: 'Which is the smallest prime number?',
    options: ['0', '1', '2', '3'],
    correctIndex: 2
  },
  {
    text: 'Which language runs in a web browser?',
    options: ['C', 'Java', 'Python', 'JavaScript'],
    correctIndex: 3
  },
  {
    text: 'How many continents are there on Earth?',
    options: ['5', '6', '7', '8'],
    correctIndex: 2
  }
];

export const seedQuestions = async () => {
  try {
    const count = await Question.countDocuments();
    if (count === 0) {
      await Question.insertMany(data);
      console.log('Seeded 10 questions');
    }
  } catch (err) {
    console.error('Seeding error:', err);
  }
};
