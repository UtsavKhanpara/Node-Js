// public/js/quiz.js
// Frontend-only quiz state (no server sessions).
// Server provides window.__QUESTIONS__ as an array.

(function () {
  const questions = window.__QUESTIONS__ || [];
  if (!questions.length) {
    document.getElementById('quiz-area').innerHTML = '<p>No questions found.</p>';
    return;
  }

  const qText = document.getElementById('questionText');
  const optionsBox = document.getElementById('options');
  const nextBtn = document.getElementById('nextBtn');
  const progress = document.getElementById('progress');

  let current = 0;
  let right = 0;
  let wrong = 0;
  let locked = false; // true after selection for current question

  function renderQuestion() {
    locked = false;
    nextBtn.disabled = true;
    const q = questions[current];
    qText.textContent = `${current + 1}. ${q.text}`;

    optionsBox.innerHTML = '';
    q.options.forEach((opt, i) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'btn btn-outline-secondary answer-btn';
      btn.dataset.index = i;
      btn.textContent = opt;
      btn.addEventListener('click', () => handleSelect(btn, i));
      optionsBox.appendChild(btn);
    });

    progress.textContent = `${current + 1} of ${questions.length} questions`;
  }

  function handleSelect(btn, idx) {
    if (locked) return;
    const q = questions[current];
    const btns = Array.from(optionsBox.querySelectorAll('button'));
    btns.forEach(b => (b.disabled = true)); // prevent re-clicks

    const correctIdx = q.correctIndex;
    if (idx === correctIdx) {
      btn.classList.add('selected-correct');
      right++;
    } else {
      btn.classList.add('selected-wrong');
      // highlight correct one
      const correctBtn = btns.find(b => Number(b.dataset.index) === correctIdx);
      if (correctBtn) correctBtn.classList.add('reveal-correct');
      wrong++;
    }

    locked = true;
    nextBtn.disabled = false;
  }

  nextBtn.addEventListener('click', () => {
    if (!locked) {
      // guard: shouldn't happen because Next disabled, but just in case
      alert('Please select an answer first.');
      return;
    }
    current++;
    if (current < questions.length) {
      renderQuestion();
    } else {
      // finished -> go to result page with query params
      const params = new URLSearchParams({ right: String(right), wrong: String(wrong) });
      window.location.href = '/result?' + params.toString();
    }
  });

  // initial render
  renderQuestion();
})();
