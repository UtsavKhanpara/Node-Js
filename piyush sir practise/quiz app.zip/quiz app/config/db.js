// config/db.js
import mongoose from 'mongoose';
import { seedQuestions } from '../seed/questions.js';

export const connectDB = async () => {
  const uri = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/quiz_app';
  try {
    await mongoose.connect(uri);
    console.log('MongoDB connected');
    // seed static 10 questions if empty
    await seedQuestions();
  } catch (err) {
    console.error('MongoDB connection error:', err);
    process.exit(1);
  }
};
