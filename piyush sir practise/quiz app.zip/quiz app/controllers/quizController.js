// controllers/quizController.js
import Question from '../models/Question.js';

export const getQuizPage = async (req, res) => {
  try {
    // send ALL questions to client (client will control flow)
    const questions = await Question.find().lean();
    res.render('quiz', { questions });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server Error');
  }
};

export const getResultPage = (req, res) => {
  // counts come from query params sent by client
  const right = Number(req.query.right) || 0;
  const wrong = Number(req.query.wrong) || 0;
  const total = right + wrong;
  res.render('result', { right, wrong, total });
};
