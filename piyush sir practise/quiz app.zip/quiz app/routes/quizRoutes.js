// routes/quizRoutes.js
import { Router } from 'express';
import { getQuizPage, getResultPage } from '../controllers/quizController.js';

const router = Router();

router.get('/', getQuizPage);        // renders quiz with all questions
router.get('/result', getResultPage); // result page reads counts from query

export default router;
