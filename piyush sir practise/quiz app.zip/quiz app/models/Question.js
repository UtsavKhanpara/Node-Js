// models/Question.js
import mongoose from 'mongoose';

const questionSchema = new mongoose.Schema(
  {
    text: { type: String, required: true },
    options: {
      type: [String],
      required: true,
      validate: {
        validator: (v) => Array.isArray(v) && v.length === 4,
        message: 'Options must be an array of 4 strings'
      }
    },
    correctIndex: { type: Number, required: true, min: 0, max: 3 }
  },
  { timestamps: true }
);

export default mongoose.model('Question', questionSchema);
